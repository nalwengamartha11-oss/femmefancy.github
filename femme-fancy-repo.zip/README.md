# Femme Fancy

Static online store: HTML, TailwindCSS (CDN) and vanilla JS. No build step.

- `index.html` page markup
- `style.css` custom styles (polka dots, cards, checkout)
- `main.js` products, cart, search, checkout
- `images/` product photos (swap for your own, keep the file names or update `main.js`)

Deploy: connect this repo to Netlify, leave the build command empty and publish directory as `.`
