/* ---------- Products ----------
   Suggested USD prices: change the `price` on any line to suit your costs.
   `img` points to the photo stored in the IMG block above this script. */
const products = [
  { id: 1, name: "Garden Party Corset Set", cat: "Sets", price: 98, img: "images/garden-corset.jpg",
    desc: "A floral-striped corset top and matching mini skirt, tailored like something found in a grandmother's trunk. Pretty, polished and quietly expensive." },
  { id: 2, name: "Cloud Ruffle Halter Set", cat: "Sets", price: 86, img: "images/cloud-ruffle.jpg",
    desc: "Pleated ivory halter and tiered skirt that move like whipped cream. Soft girl on the surface, old money in the details." },
  { id: 3, name: "Pearl Button Blazer Dress", cat: "Dresses", price: 124, img: "images/pearl-blazer.jpg",
    desc: "A sharply tailored blazer dress with a pearl-button bodice and a softly draped skirt. Power dressing, but make it romantic." },
  { id: 4, name: "Rosé Embroidered Halter Set", cat: "Sets", price: 82, img: "images/rose-halter.jpg",
    desc: "A blush halter corset and wrap skirt stitched with tone-on-tone vines. Tie the ribbons and the whole look falls into place." },
  { id: 5, name: "Pinstripe Corset Set", cat: "Sets", price: 94, img: "images/pinstripe-corset.jpg",
    desc: "Candy-pink pinstripes cut into a structured corset top and easy wide-leg trousers. Boardroom polish with a wink." },
  { id: 6, name: "Cherry Blossom Cream Set", cat: "Sets", price: 88, img: "images/cherry-cream.jpg",
    desc: "A cream halter top and pocketed mini skirt embroidered with delicate pink blossoms. Spring in its most refined form." },
  { id: 7, name: "Noir Blossom Set", cat: "Sets", price: 88, img: "images/noir-blossom.jpg",
    desc: "A black tailored top and mini skirt, edged in blush and scattered with hand-stitched blossoms. Dark, delicate and a little dramatic." },
  { id: 8, name: "Polka Bow Mules", cat: "Accessories", price: 76, img: "images/polka-mules.jpg",
    desc: "Chocolate satin mules dotted in blush polka dots with a perfectly tied bow. A little heel for a lot of confidence." },
  { id: 9, name: "Powder Blue Pearl Cardigan", cat: "Tops", price: 58, img: "images/powder-cardi.jpg",
    desc: "A featherlight knit with a row of pearl studs along the shoulder. Soft to the touch, sweet without trying." },
  { id: 10, name: "Pinstripe Bow Dress", cat: "Dresses", price: 79, img: "images/pinstripe-bow.jpg",
    desc: "A fine-pinstripe black dress with gold buttons and velvet bows at the neckline and waist. Think Parisian schoolgirl, all grown up." },
  { id: 11, name: "Heart Print Teddy Pouch", cat: "Accessories", price: 24, img: "images/teddy-pouch.jpg",
    desc: "Cloud-soft teddy pouches lined in pink hearts, made for lipsticks and love notes. A tiny luxury you'll carry everywhere." },
  { id: 12, name: "Smoke Flared-Cuff Set", cat: "Sets", price: 92, img: "images/smoke-set.jpg",
    desc: "A fitted button-front top with dramatically flared cuffs and a matching mini skirt in soft charcoal. Understated, sculpted and effortlessly chic." },
  { id: 13, name: "Blush Pinstripe Hook Top", cat: "Tops", price: 48, img: "images/hook-top.jpg",
    desc: "A draped pinstripe blouse cinched with gold hook closures at the waist. Feminine structure with a hint of vintage." },
  { id: 14, name: "Burgundy Collar Rib Knit", cat: "Tops", price: 46, img: "images/collar-knit.jpg",
    desc: "A ribbed pink knit with bold burgundy stripes and a statement polo collar. Preppy, polished and just a bit playful." },
  { id: 15, name: "Pink Collared Rib Tee", cat: "Tops", price: 38, img: "images/collar-tee.jpg",
    desc: "A fitted rib-knit tee layered with a pinstripe shirt collar. The easiest way to look put-together." },
  { id: 16, name: "Bow Slip Maxi", cat: "Dresses", price: 68, img: "images/slip-maxi.jpg",
    desc: "A sculpted blush maxi with delicate straps and one tiny satin bow. Sleek, soft and made to be remembered." },
  { id: 17, name: "Open-Back Satin Bow Dress", cat: "Dresses", price: 84, img: "images/open-back.jpg",
    desc: "A fitted dress that dips low in the back, finished with a generous satin bow. Turn around slowly." },
  { id: 18, name: "Crystal Bow Satin Set", cat: "Sets", price: 72, img: "images/crystal-set.jpg",
    desc: "A blush satin cami and shorts tied with sparkling crystal bows. For lazy mornings that still feel like an occasion." },
  { id: 19, name: "Pointelle Knit Open-Back Dress", cat: "Dresses", price: 78, img: "images/pointelle.jpg",
    desc: "A long-sleeved pointelle knit that hugs every curve and ties low at the back. Romantic, textural and unapologetically feminine." },
  { id: 20, name: "Peony Rosette Mini", cat: "Dresses", price: 74, img: "images/peony-mini.jpg",
    desc: "A watercolour-floral mini with a sculpted rosette bodice and a ruffled hem. Made for garden parties and golden hour." },
  { id: 21, name: "Leopard Lace Slip", cat: "Dresses", price: 56, img: "images/leopard-slip.jpg",
    desc: "A leopard-print mini finished with black lace at the bust and hem. Bold, but always with a soft edge." },
  { id: 22, name: "Gingham Bow Set", cat: "Sets", price: 52, img: "images/gingham-set.jpg",
    desc: "A pink gingham tie-front top with smocked ruffle shorts edged in lace. Sweet as a summer picnic." },
  { id: 23, name: "Bordeaux Bow Set", cat: "Sets", price: 54, img: "images/bordeaux-set.jpg",
    desc: "A ruched bandeau and button-front shorts in deep ribbed bordeaux, each with a pink bow. Rich colour, softest details." },
  { id: 24, name: "Noir Bow Cami Set", cat: "Sets", price: 48, img: "images/noir-cami.jpg",
    desc: "A black cami and mini shorts, each finished with a tiny white bow. The little black set that does it all." },
  { id: 25, name: "Ruffle Hem Tube Dress", cat: "Dresses", price: 62, img: "images/tube-dress.jpg",
    desc: "A bandeau mini with a tiered ruffle hem and ribbon bow, in blush, cream and black. Choose your mood." },
  { id: 26, name: "Ivory Noir-Bow Set", cat: "Sets", price: 52, img: "images/ivory-set.jpg",
    desc: "Ribbed ivory bandeau and shorts trimmed in black picot lace, each with a tiny black bow. Clean, crisp and a little coquette." },
  { id: 27, name: "Lace Bow Bandeau Dress", cat: "Dresses", price: 64, img: "images/lace-bow-dress.jpg",
    desc: "A blush bandeau dress with a black lace bodice and a ribbon tied at the bust. The prettiest little dress for dinner." },
  { id: 28, name: "Lace-Up Corset Mini", cat: "Dresses", price: 96, img: "images/lace-up.jpg",
    desc: "A white satin corset mini laced down the front, with a floaty chiffon flounce. Bridal energy, any day of the week." },
  { id: 29, name: "Crystal-Trim Satin Cowl Top", cat: "Tops", price: 44, img: "images/satin-cowl.jpg",
    desc: "A blush satin cowl top outlined in sparkling crystals. Dress it up with silk trousers, or down with denim." },
  { id: 30, name: "Pearl Collar Vest Set", cat: "Sets", price: 108, img: "images/pearl-vest.jpg",
    desc: "A collared halter vest and mini skirt with lace-trimmed hems, in blush and white. Add pearls and nothing else is needed." },
  { id: 31, name: "Pleated Polo Dress", cat: "Dresses", price: 72, img: "images/polo-dress.jpg",
    desc: "A polo-collar mini dress with a pleated skirt and contrast piping in blush, ivory and black. Country club, but make it cute." },
  { id: 32, name: "Lace-Trim Playsuit", cat: "Sets", price: 58, img: "images/lace-playsuit.jpg",
    desc: "A blush bandeau playsuit with black lace at the bust and hem and a satin bow at the centre. Soft girl meets after-dark." },
  { id: 33, name: "Butter Satin Lace Slip", cat: "Dresses", price: 86, img: "images/butter-slip.jpg",
    desc: "A butter-yellow satin slip edged in blush lace, with a matching robe. Breakfast in bed, but make it editorial." },
  { id: 34, name: "Blush Lace Babydoll", cat: "Dresses", price: 54, img: "images/babydoll.jpg",
    desc: "A dreamy pink babydoll with a lace bodice and a scalloped, feather-light hem. The softest way to say goodnight." },
  { id: 35, name: "Polka Pyjama Set", cat: "Sets", price: 68, img: "images/polka-pjs.jpg",
    desc: "A long-sleeve top and wide-leg trousers sprinkled with tiny polka dots. Cosy enough for the cabin, chic enough for the airport." },
  { id: 36, name: "Lilac Long-Sleeve Playsuit", cat: "Sets", price: 56, img: "images/lilac-playsuit.jpg",
    desc: "A second-skin playsuit in soft lilac with a scooped neckline and a tiny bow. Easy, sleek and endlessly layerable." },
  { id: 37, name: "Pink Structured Mini Suit", cat: "Sets", price: 128, img: "images/pink-suit.jpg",
    desc: "A powder-pink blazer with a corseted bodice and a draped mini skirt. Tailoring that blushes." },
  { id: 38, name: "Mocha Corset Mini Set", cat: "Sets", price: 118, img: "images/mocha-set.jpg",
    desc: "A softly structured corset top with puffed sleeves and a matching mini skirt in warm mocha. Quiet luxury, beautifully cut." },
  { id: 39, name: "Ivory Sleeve Corset Top", cat: "Tops", price: 62, img: "images/ivory-corset.jpg",
    desc: "A cream corset blouse with sculpted sleeves and a row of pearl buttons. Pair with denim for easy elegance." },
  { id: 40, name: "Champagne Satin Corset Set", cat: "Sets", price: 138, img: "images/champagne-set.jpg",
    desc: "An off-shoulder corset top with draped sleeves and a satin maxi skirt in champagne. Made for candlelit evenings." },
];

const grid = document.getElementById('grid');
const fmt = n => '$' + n.toFixed(0);
let query = '', activeCat = 'All';

/* ---------- Render product grid ---------- */
function renderProducts(list) {
  grid.innerHTML = list.map(p => `
    <article class="card reveal" data-open="${p.id}" tabindex="0" role="button" aria-label="View ${p.name}">
      <div class="tile" style="background:#F8C4D0">
        <img src="${p.img}" alt="${p.name}" loading="lazy" decoding="async">
      </div>
      <div class="px-1 pt-4 text-center">
        <p class="eyebrow opacity-50 !text-[.62rem]">${p.cat}</p>
        <h3 class="font-serif text-xl leading-tight mt-1">${p.name}</h3>
        <p class="text-sm opacity-70 mt-1">${fmt(p.price)}</p>
        <button class="btn btn-ghost !px-5 !py-2 mt-3" data-add="${p.id}">Add to Cart</button>
      </div>
    </article>`).join('');
  document.getElementById('empty').classList.toggle('hidden', list.length > 0);
  observe();
}

/* search + category tabs work together */
function applyFilters() {
  renderProducts(products.filter(p =>
    (activeCat === 'All' || p.cat === activeCat) &&
    (p.name + ' ' + p.cat + ' ' + p.desc).toLowerCase().includes(query)));
}
document.getElementById('cats').addEventListener('click', e => {
  const b = e.target.closest('[data-cat]'); if (!b) return;
  activeCat = b.dataset.cat;
  document.querySelectorAll('[data-cat]').forEach(x => x.classList.toggle('on', x === b));
  applyFilters();
});

/* ---------- Product quick-view modal ---------- */
const modal = document.getElementById('modal');
function openModal(id) {
  const p = products.find(x => x.id === id); if (!p) return;
  document.getElementById('mImg').src = p.img;
  document.getElementById('mImg').alt = p.name;
  document.getElementById('mCat').textContent = p.cat;
  document.getElementById('mName').textContent = p.name;
  document.getElementById('mPrice').textContent = fmt(p.price);
  document.getElementById('mDesc').textContent = p.desc;
  document.getElementById('mAdd').dataset.add = p.id;
  modal.classList.add('open'); document.body.style.overflow = 'hidden';
}
function closeModal() { modal.classList.remove('open'); document.body.style.overflow = ''; }
grid.addEventListener('click', e => {
  if (e.target.closest('[data-add]')) return;           // "Add to Cart" shouldn't open the modal
  const c = e.target.closest('[data-open]'); if (c) openModal(+c.dataset.open);
});
grid.addEventListener('keydown', e => {
  if (e.key === 'Enter' && e.target.dataset.open) openModal(+e.target.dataset.open);
});
modal.addEventListener('click', e => { if (e.target === modal || e.target.closest('[data-close],[data-add]')) closeModal(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });

/* ---------- Search (desktop + mobile inputs stay in sync) ---------- */
function filter(q) {
  query = q.trim().toLowerCase();
  applyFilters();
  if (query) document.getElementById('collection').scrollIntoView();
}
['search', 'searchM'].forEach(id => document.getElementById(id).addEventListener('input', e => {
  document.getElementById(id === 'search' ? 'searchM' : 'search').value = e.target.value;
  filter(e.target.value);
}));

/* ---------- Cart ---------- */
let cart = [];
// remember the bag between visits; re-sync with the current catalogue so old prices never linger
try { cart = (JSON.parse(localStorage.getItem('ff-cart')) || []).map(i => { const p = products.find(x => x.id === i.id); return p ? { ...p, qty: i.qty } : null; }).filter(Boolean); } catch (e) { cart = []; }
const drawer = document.getElementById('drawer'), scrim = document.getElementById('scrim');
const toggleCart = open => { drawer.classList.toggle('open', open); scrim.classList.toggle('open', open); };

function renderCart() {
  const box = document.getElementById('cartItems');
  box.innerHTML = cart.length ? cart.map(i => `
    <div class="flex gap-3 items-center border-b border-blush pb-3">
      <img src="${i.img}" alt="" class="w-16 h-20 object-cover border border-blush">
      <div class="flex-1 min-w-0">
        <p class="font-serif text-lg leading-tight">${i.name}</p>
        <p class="text-xs opacity-60">${fmt(i.price)} each</p>
        <button data-rm="${i.id}" class="text-[11px] underline opacity-60 mt-1">Remove</button>
      </div>
      <div class="flex items-center gap-2 text-sm">
        <button data-dec="${i.id}" class="w-6 h-6 border border-current rounded-full" aria-label="Fewer">−</button>
        <span>${i.qty}</span>
        <button data-inc="${i.id}" class="w-6 h-6 border border-current rounded-full" aria-label="More">+</button>
      </div>
    </div>`).join('') : '<p class="font-serif italic text-lg text-center mt-10 opacity-70">Your bag is waiting to be filled.</p>';
  const sub = subtotal();
  document.getElementById('cartTotal').textContent = money(sub);
  document.getElementById('cartCount').textContent = cart.reduce((n, i) => n + i.qty, 0);
  document.getElementById('shipHint').textContent = !cart.length ? '' : sub >= FREE_SHIP ? 'You\'ve unlocked free standard shipping ✨' : 'Add ' + money(FREE_SHIP - sub) + ' more for free standard shipping';
  try { localStorage.setItem('ff-cart', JSON.stringify(cart.map(i => ({ id: i.id, qty: i.qty })))); } catch (e) {}
}
function change(id, d) {
  const item = cart.find(i => i.id === id); if (!item) return;
  item.qty += d; if (item.qty <= 0) cart = cart.filter(i => i.id !== id);
  renderCart();
}
document.addEventListener('click', e => {
  const t = e.target.closest('[data-add],[data-inc],[data-dec],[data-rm]'); if (!t) return;
  if (t.dataset.add) {
    const p = products.find(x => x.id == t.dataset.add), ex = cart.find(i => i.id === p.id);
    ex ? ex.qty++ : cart.push({ ...p, qty: 1 });
    renderCart(); toggleCart(true);
  }
  if (t.dataset.inc) change(+t.dataset.inc, 1);
  if (t.dataset.dec) change(+t.dataset.dec, -1);
  if (t.dataset.rm) { cart = cart.filter(i => i.id !== +t.dataset.rm); renderCart(); }
});
document.getElementById('cartBtn').onclick = () => toggleCart(true);
document.getElementById('closeCart').onclick = scrim.onclick = () => toggleCart(false);
/* ---------- Checkout ---------- */
// Payment isn't connected yet. Once you have a payment processor, paste its checkout link here
// and customers will be sent to it after they place their order.
const STORE = { paymentLink: '' };
const FREE_SHIP = 120, SHIP = { standard: 8, express: 18 };
const money = n => '$' + n.toFixed(2);
const subtotal = () => cart.reduce((t, i) => t + i.price * i.qty, 0);
const shipCost = () => {
  const m = document.querySelector('input[name=ship]:checked').value;
  return (m === 'standard' && subtotal() >= FREE_SHIP) ? 0 : SHIP[m];
};
const coView = document.getElementById('checkout-view');
const coForm = document.getElementById('coForm');

function summaryRows(sub, ship) {
  const row = (a, b, strong) => `<div class="flex justify-between ${strong ? 'font-serif text-xl pt-2 border-t border-blush' : ''}"><span>${a}</span><span>${b}</span></div>`;
  return row('Subtotal', money(sub)) + row('Shipping', ship ? money(ship) : 'Free') + row('Total', money(sub + ship), true);
}
function renderSummary() {
  const sub = subtotal(), ship = shipCost();
  document.getElementById('shipStd').textContent = sub >= FREE_SHIP ? 'Free' : money(SHIP.standard);
  document.getElementById('coItems').innerHTML = cart.map(i => `
    <div class="flex gap-3 items-center">
      <div class="relative"><img src="${i.img}" alt="" class="w-14 h-[4.5rem] object-cover border border-blush"><span class="absolute -top-2 -right-2 bg-black text-white text-[10px] w-5 h-5 rounded-full grid place-items-center">${i.qty}</span></div>
      <p class="flex-1 font-serif leading-tight">${i.name}</p><p class="text-sm">${money(i.price * i.qty)}</p>
    </div>`).join('');
  document.getElementById('coTotals').innerHTML = summaryRows(sub, ship);
}
function openCheckout() {
  if (!cart.length) { document.getElementById('shipHint').textContent = 'Add something lovely to your bag first.'; return; }
  toggleCart(false);
  document.getElementById('coMain').classList.remove('hidden');
  document.getElementById('coDone').classList.add('hidden');
  document.getElementById('coErr').textContent = '';
  renderSummary();
  coView.classList.add('open'); document.body.style.overflow = 'hidden'; coView.scrollTop = 0;
}
function closeCheckout() { coView.classList.remove('open'); document.body.style.overflow = ''; }
coForm.addEventListener('change', e => { if (e.target.name === 'ship') renderSummary(); });
document.getElementById('coBack').onclick = closeCheckout;
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeCheckout(); });

// Hook for your backend or email service (Formspree, EmailJS, your own API...). Receives the full order.
function sendOrder(order) { /* e.g. fetch('https://your-endpoint', { method: 'POST', body: JSON.stringify(order) }) */ }

coForm.addEventListener('submit', e => {
  e.preventDefault();
  const err = document.getElementById('coErr');
  if (!coForm.checkValidity()) { err.textContent = 'Please fill in the highlighted details so we know where to send your order.'; coForm.reportValidity(); return; }
  err.textContent = '';
  const data = Object.fromEntries(new FormData(coForm));
  const sub = subtotal(), ship = shipCost();
  const order = { no: 'FF-' + Math.floor(100000 + Math.random() * 900000), items: cart.map(i => ({ id: i.id, name: i.name, qty: i.qty, price: i.price })), subtotal: sub, shipping: ship, total: sub + ship, customer: data };
  sendOrder(order);
  if (STORE.paymentLink) { window.location.href = STORE.paymentLink; return; }
  const done = document.getElementById('coDone');
  done.innerHTML = `
    <p class="eyebrow opacity-60">Thank you</p>
    <h2 class="script text-6xl md:text-7xl mt-2">Order received</h2>
    <p class="font-serif italic text-xl mt-3">Order <span id="dNo"></span> · a confirmation is on its way to <span id="dMail"></span></p>
    <div class="bg-[var(--paper)] border-[1.5px] border-blush p-5 mt-8 text-left text-sm space-y-2">${summaryRows(sub, ship)}</div>
    ${STORE.paymentLink ? '' : '<p class="text-xs opacity-60 mt-4">Preview mode: payment isn\'t connected yet, so nothing was charged.</p>'}
    <button id="dBack" class="btn mt-8">Continue shopping</button>`;
  done.querySelector('#dNo').textContent = order.no;
  done.querySelector('#dMail').textContent = data.email;
  done.querySelector('#dBack').onclick = closeCheckout;
  document.getElementById('coMain').classList.add('hidden');
  done.classList.remove('hidden'); coView.scrollTop = 0;
  cart = []; renderCart(); coForm.reset();
});
document.getElementById('checkout').onclick = openCheckout;


/* ---------- Mobile menu ---------- */
const mNav = document.getElementById('mobileNav');
document.getElementById('menuBtn').onclick = () => { mNav.classList.toggle('hidden'); mNav.classList.toggle('flex'); };
mNav.addEventListener('click', () => { mNav.classList.add('hidden'); mNav.classList.remove('flex'); });

/* ---------- Newsletter (front-end only for now) ---------- */
document.getElementById('news').addEventListener('submit', e => {
  e.preventDefault();
  document.getElementById('newsMsg').textContent = 'Welcome to the circle, darling. Check your inbox.';
  e.target.reset();
});

/* ---------- Fade in on scroll ---------- */
let io;
function observe() {
  io = io || new IntersectionObserver((entries) => entries.forEach(en => {
    if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
  }), { threshold: .12 });
  document.querySelectorAll('.reveal:not(.in), .dots-fade:not(.in)').forEach(el => io.observe(el));
}

document.getElementById('yr').textContent = new Date().getFullYear();
renderProducts(products); renderCart(); observe();
